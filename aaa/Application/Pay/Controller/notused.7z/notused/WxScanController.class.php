<?php
namespace Pay\Controller;



use Org\Util\WxH5Pay;
use Think\Exception;



class WxScanController extends PayController
{
    public function __construct()
    {
        parent::__construct();
    }

    //支付
    public function Pay($array)
    {
        $orderid     = I("request.pay_orderid");
        $body        = I('request.pay_productname');
        $notifyurl   = $this->_site . 'Pay_WxScan_notifyurl.html'; //异步通知
        $callbackurl = $this->_site . 'Pay_WxScan_callbackurl.html'; //返回通知

        $parameter = array(
            'code'         => 'WxScan', // 通道名称
            'title'        => '微信扫码',
            'exchange'     => 1, // 金额比例
            'gateway'      => '',
            'orderid'      => '',
            'out_trade_id' => $orderid,
            'body'         => $body,
            'channel'      => $array,
        );

        // 订单号，可以为空，如果为空，由系统统一的生成
        $return = $this->orderadd($parameter);

        $return['subject'] = $body;

        //---------------------引入支付宝第三方类-----------------
        $notifyurl = $this->_site . 'Pay_WxScan_notifyurl.html'; //异步通知
        $redirect_uri = $this->_site . 'Pay_WxScan_callbackurl.html?out_trade_no='.$return['orderid'];
        $wxwapPay = new WxH5Pay($return['appid'], $return['mch_id'], $notifyurl, $return['signkey']);
        $params['body'] = "商城订单";
        $params['out_trade_no'] = $return['orderid'];
        $params['total_fee'] = $return['amount']*100;
        $params['trade_type'] = 'NATIVE';
        $params['scene_info'] = '{"h5_info": {"type":"Wap","wap_url": "h'.$this->site.'","wap_name": "'."商城订单".'"}}';
        $result = $wxwapPay->unifiedOrder( $params );
        $url = $result['code_url'];
        import("Vendor.phpqrcode.phpqrcode",'',".php");
        $QR = "Uploads/codepay/". $return['orderid'] . ".png";
        \QRcode::png($url, $QR, "L", 20);
        $this->assign("imgurl", '/'.$QR);
        $this->assign('params',$return);
        $this->assign('orderid',$return['orderid']);
        $this->assign('zfbpayUrl',$url);
        $this->assign('money',sprintf('%.2f',$return['amount']));
        $this->display("WeiXin/weixin");die;
    }

    public function topay(){
        $url = "https://wx.tenpay.com/cgi-bin/mmpayweb-bin/checkmweb?prepay_id=wx2219235560685867ae6b8ea31967294592&package=4234162603";
        header('Location: '.$url);
    }
    //同步通知
    public function callbackurl()
    {
        $Order      = M("Order");

        $pay_status = $Order->where(['pay_orderid' => $_REQUEST["out_trade_no"]])->getField("pay_status");
        if ($pay_status != 0) {
            $this->EditMoney($_REQUEST["out_trade_no"], '', 1);
        } else {
            $this->State($_REQUEST["out_trade_no"]);die;
            //redirect($this->_site . 'Pay_Weixin_callbackurl.html?out_trade_no='.$_REQUEST["out_trade_no"]);
        }
    }
    public function Success(){
        $this->display("WeiXin/success");die;
    }
    public function State($orderid){
        $Order   = M("Order");
        $order   = $Order->where(array('pay_orderid' => $orderid))->find();
        $this->assign('orderid',$orderid);
        $this->display("WeiXin/state");die;
    }
    public function notifyurl()
    {
        // 获取微信回调的数据
        $notifiedData = file_get_contents('php://input');

        //XML格式转换
        $xmlObj = simplexml_load_string($notifiedData, 'SimpleXMLElement', LIBXML_NOCDATA);
        $xmlObj = json_decode(json_encode($xmlObj),true);

        if ($xmlObj['return_code'] == "SUCCESS" && $xmlObj['result_code'] == "SUCCESS") {
            foreach ($xmlObj as $k => $v) {
                if ($k == 'sign') {
                    $xmlSign = $xmlObj[$k];
                    unset($xmlObj[$k]);
                };
            }
            $sign = http_build_query($xmlObj);
            //md5处理
            $key1 = getKey($xmlObj["out_trade_no"]);
            $sign = md5($sign . '&key=' .$key1);

            //转大写
            $sign = strtoupper($sign);
            if ($sign === $xmlSign) {
                $result = $this->EditMoney($xmlObj['out_trade_no'], 'Weixin', 0);
                exit("success");
            }
        }
        // if($sign != strtolower($data['sign'])) exit('sign err');



        //
    }



}