<?php
namespace Pay\Controller;

use Think\Controller;
/**
 * Created by PhpStorm.
 * User: feng
 * Date: 2017/10/24
 * Time: 11:18
 */
class CheckoutController extends PayController{
    public function index(){

        $this->display();
    }
}